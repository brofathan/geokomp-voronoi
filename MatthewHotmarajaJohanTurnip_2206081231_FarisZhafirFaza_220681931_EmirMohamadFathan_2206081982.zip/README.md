# Voronoi Geometri Komputasi

- Emir Mohamad Fathan 2206081982
- Faris Zhafir Faza 2206081931
- Matthew Hotmaraja J.T 2206081231

Penggunaan :

1. Menjalankan script berikut

```
python gui.py
```

2. Terdapat 2 opsi, yaitu menambah titik dengan menggunakan cursor langsung atau menggunakan file txt

   - Dengan cursor

     Dapat langsung meng-klik mouse kiri satu kali pada canvas.

   - Dengan txt

     Menulis titik (x,y) dengan format berikut

     ```
     x1 y1
     x2 y2
     ...
     ```

     Kemudian menekan tombol

3. Menekan tombol draw untuk melihat hasil penggambaran diagram voronoi dari titik-titik yang sudah di-plot

4. Tombol "clear" dapat ditekan untuk menghapus diagram voronoi pada canvas